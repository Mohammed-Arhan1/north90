// script.js
document.getElementById('mobile-menu').addEventListener('click', function() {
    const menu = document.querySelector('.navbar-menu');
    menu.classList.toggle('active');
});

// script.js
document.querySelector('.collapse-btn').addEventListener('click', function() {
    const menu = document.querySelector('.menu');
    menu.classList.toggle('collapsed');
});

document.getElementById('back-arrow').addEventListener('click', function() {
    const leftMenu = document.querySelector('.left-menu');
    leftMenu.classList.add('collapsed');
});

document.getElementById('show-menu-btn').addEventListener('click', function() {
    const leftMenu = document.querySelector('.left-menu');
    leftMenu.classList.remove('collapsed');
});