def lambda_handler(event, context):
    # Retrieve the numbers from the event
    number1 = event.get('number1')
    number2 = event.get('number2')
    
    # Perform the addition
    result = number1 + number2
    
    # Return the result
    return {
        'statusCode': 200,
        'body': {
            'result': result
        }
    }
